//The images in this program come from:
//https://pixabay.com/illustrations/globe-world-languages-translate-110775/
//https://pixabay.com/illustrations/school-board-languages-blackboard-1063556/

//Variables
//Lists from Most Spoken Languages WorldWide
var languageList = getColumn("Most Spoken Languages Worldwide","Language");
var speakersList = getColumn("Most Spoken Languages Worldwide","Speakers in millions");
var branchList = getColumn("Most Spoken Languages Worldwide","Branch");
var filteredLanguageList = [];
var speakerIndex;
//Output variable
var output = "There are no other languages in your language famiy. \
You're unique! If you want to start learning a language, \
you can start with English which has billions of speakers worldwide.";

//Sets Options to the indexes in languageList
setProperty("languageDropdown", "options", languageList);

//Call of Function
updateScreen(getProperty("languageDropdown", "index"), getText("languageDropdown"));

//OnEvents
//Switches to mainscreen
onEvent("startButton", "click", function(){
  setScreen("mainScreen");
});

onEvent("backButton","click", function(){
  setScreen("homeScreen");
});

onEvent("languageDropdown", "change", function(){
  updateScreen(getProperty("languageDropdown", "index"), getText("languageDropdown"));
});


//Function
//Updates the screen based on the user's language and uses app logic 
//to determine number of speakers, family, and languages in the same family
//by traversing the list and filtering it. 
function updateScreen(index, language, family){
   filteredLanguageList = [];
  for (var i = 0; i < languageList.length; i++){
    if (languageList[i] == language){
      family = branchList[i];
      speakerIndex = speakersList[index];
    }
  } for (var j = 0; j < branchList.length; j++){
    if (branchList[j] == family){
      appendItem(filteredLanguageList,languageList[j]);
    }
  }
  //Outputs the results to the user. 
  if (filteredLanguageList.length > 1){
    setText("output", "You speak a language in the" 
+ family + " language family." + language  + " has " + speakerIndex 
+ " million native speakers. That's a lot! You can learn any of these languages: " 
+ filteredLanguageList.join(", ") + ".");
  } else {setText("output", "You speak a language in the " 
  + family + " language family. " + language 
  + " has " + speakerIndex + " million speakers. That's a lot! " 
  + output);
}
} 
