//VARIABLES AND LISTS
var wordsList = getColumn("Words", "Word");
var filteredWordsList = [];
var abc = [];
var wordsTried = [];
var index = 0;

filter();
alphabetize();
removeItem(abc,0);
removeItem(abc,0);

//HOMESCREEN
//OnEvents for buttons
onEvent("startButton","click", function(){
  setScreen("gameScreen");
});
onEvent("wordListButton","click", function(){
  setScreen("listScreen");
});
onEvent("statsButton","click", function(){
  setScreen("statScreen");
});

//Code for please wait label until filtering of ABC is complete
if (abc.length == 830){
  setText("pleaseWaitLabel", "You're ready to go!");
  setProperty("pleaseWaitLabel","text-color","green");
}
//LIST SCREEN
//OnEvents for buttons
setText("listTextBox",abc[index]);
onEvent("gameButton2","click", function(){
  setScreen("gameScreen");
});
onEvent("statsButton3","click", function(){
  setScreen("statScreen");
});
onEvent("homeButton2","click", function(){
  setScreen("homeScreen");
});

//OnEvents for List Scrolling Pattern
onEvent("rightButton","click", function(){
  if (index < abc.length-1){
    index = index + 1;
    }else if (index==abc.length-1){
      index = 0; 
      }  setText("listTextBox", abc[index]);
});

onEvent("leftButton","click", function(){
  if (index > 0){
    index = index - 1;
    } else if (index==0){
      index = abc.length-1; 
      } setText("listTextBox", abc[index]);
});

onEvent("rightButton1","click", function(){
  if (index + 10 > abc.length){
      index = 0; 
    }else if (index < abc.length-1){
      index = index + 10;
      }  setText("listTextBox", abc[index]);
});

onEvent("leftButton1","click", function(){
  if (index - 10 < 0){
    index = abc.length-1;
    } else if (index > 0){
      index = index - 10; 
      } setText("listTextBox", abc[index]);
});

onEvent("rightButton2","click", function(){
  if (index + 20 > abc.length){
      index = 0; 
    }else if (index < abc.length-1){
      index = index + 20;
      }  setText("listTextBox", abc[index]);
});

onEvent("leftButton2","click", function(){
  if (index - 20 < 0){
    index = abc.length-1;
    } else if (index > 0){
      index = index - 20; 
      } setText("listTextBox", abc[index]);
});

onEvent("rightButton3","click", function(){
  if (index + 50 > abc.length){
      index = 0; 
    }else if (index < abc.length-1){
      index = index + 50;
      }  setText("listTextBox", abc[index]);
});

onEvent("leftButton3","click", function(){
  if (index - 50 < 0){
    index = abc.length-1;
    } else if (index > 0){
      index = index-50;
      } setText("listTextBox", abc[index]);
});

onEvent("rightButton4","click", function(){
  if (index + 100 > abc.length){
      index = 0; 
    }else if (index < abc.length-1){
      index = index + 100;
      }  setText("listTextBox", abc[index]);
});

onEvent("leftButton4","click", function(){
  if (index - 100 < 0){
    index = abc.length-1;
    } else if (index > 0){
      index = index - 100; 
      } setText("listTextBox", abc[index]);
});
//StatScreen
//OnEvents for Buttons
onEvent("gameButton4","click", function(){
  setScreen("gameScreen");
});
onEvent("homeButton4","click", function(){
  setScreen("homeScreen");
});
onEvent("listButton4","click", function(){
  setScreen("listScreen");
});




//GameScreen
//OnEvents for buttons
onEvent("statsButton1","click", function(){
  setScreen("statScreen");
});
onEvent("homebutton1","click", function(){
  setScreen("homeScreen");
});
onEvent("listButton1","click", function(){
  setScreen("listScreen");
});

//Choosing random word from Abc List
//Variables for NewWord OnEvent & EnterButton OnEvent
var randomWord = abc[randomNumber(0, abc.length-1)];
var userGuess = "";
var guessNumber = 0;
//Code for updating Stats Page
//OnEvent for NewWord button and Game Reset
onEvent("newWord","click", function(){
  appendItem(wordsTried, randomWord);
  randomWord = abc[randomNumber(0, abc.length-1)];
  setText("statsTextBox", wordsTried.join("-"));
  setText("title3", "Can you guess the word?");
  guessNumber = 0;
setText("letter1", "");
setText("letter1", "");
setText("letter2", "");
setText("letter3", "");
setText("letter4", "");
setText("letter5", "");
setText("letter21", "");
setText("letter22", "");
setText("letter23", "");
setText("letter24", "");
setText("letter25", "");
setText("letter31", "");
setText("letter32", "");
setText("letter33", "");
setText("letter34", "");
setText("letter35", "");
setText("letter41", "");
setText("letter42", "");
setText("letter43", "");
setText("letter44", "");
setText("letter45", "");
setText("letter51", "");
setText("letter52", "");
setText("letter53", "");
setText("letter54", "");
setText("letter55", "");
setText("letter61", "");
setText("letter62", "");
setText("letter63", "");
setText("letter64", "");
setText("letter65", "");
setProperty("letter1","background-color","white");
setProperty("letter2","background-color","white");
setProperty("letter3","background-color","white");
setProperty("letter4","background-color","white");
setProperty("letter5","background-color","white");
setProperty("letter21","background-color","white");
setProperty("letter22","background-color","white");
setProperty("letter23","background-color","white");
setProperty("letter24","background-color","white");
setProperty("letter25","background-color","white");
setProperty("letter31","background-color","white");
setProperty("letter32","background-color","white");
setProperty("letter33","background-color","white");
setProperty("letter34","background-color","white");
setProperty("letter35","background-color","white");
setProperty("letter41","background-color","white");
setProperty("letter42","background-color","white");
setProperty("letter43","background-color","white");
setProperty("letter44","background-color","white");
setProperty("letter45","background-color","white");
setProperty("letter51","background-color","white");
setProperty("letter52","background-color","white");
setProperty("letter53","background-color","white");
setProperty("letter54","background-color","white");
setProperty("letter55","background-color","white");
setProperty("letter61","background-color","white");
setProperty("letter62","background-color","white");
setProperty("letter63","background-color","white");
setProperty("letter64","background-color","white");
setProperty("letter65","background-color","white");
});


//Code for Reseting Game TextBox
onEvent("input1","click",function(){
  setText("input1","");
});
//Code for Enter Button and user Guess check
onEvent("enterButton","click", function(){
  userGuess = getText("input1".toLowerCase());
  userGuess = userGuess.toLowerCase();
 if (userGuess.length != 5){
   setText("input1", "That's not a five letter word!");
 } else {
   
   //This for loop is here to check if userGuess (the word the user inputs)
   //Is equal to one of the indexes in the list abc
   // If the word is in the list, then it should run the fnction updateScreen() 
   // and set guessNumber = guessNumber + 1
   //Otherwise it should set the text of input1 to "That's not a valid guess" 
   // (because its not in the list) and set guessNumber = guessNumber - 1;
   updateScreen();
   guessNumber = guessNumber + 1;
   }
 });

//FUNCTION (Determines the length of each word and filters it into a new list)
function filter(){
  for(var i=0; i<wordsList.length; i++){
    /*Trying to get the length of the string in the list to determine if it's 5 and
      add it to the filtered list.*/  
    if (wordsList[i].length == 5){
      appendItem(filteredWordsList,wordsList[i]);
    }
  }
}

/*Function(Alphabetizes filteredWordsList by comparing the binary values of
characters)
*/
function alphabetize (){
  abc[0] = filteredWordsList[0];
  var iAbc = 0;
  for (var i = 1; i < filteredWordsList.length; i++) {
   iAbc = 0;
   if (abc[0] > filteredWordsList[i]) {
     insertItem(abc, 0, filteredWordsList[i]);
   } else {
     while ((iAbc < abc.length)) {
       if (abc[iAbc]<filteredWordsList[i]) {
         if (iAbc == abc.length-1 || abc[(iAbc+1)] > filteredWordsList[i]) {
           insertItem(abc, iAbc + 1, filteredWordsList[i]);
           iAbc = abc.length;
         }
       } else if (abc[iAbc] == filteredWordsList[i]){
         insertItem(abc, iAbc, filteredWordsList[i]);
        iAbc = abc.length;
       }
       iAbc = iAbc + 1;
     }
   }
  }
} 

/*Function(Updates GameScreen based on user Guess. 
Compares substrings with the userGuess and changes textboxes accordingly)*/
function updateScreen(){
  if (guessNumber == 0){
    setText("letter1" , userGuess.substring(0,1));
    setText("letter2" , userGuess.substring(1,2));
    setText("letter3" , userGuess.substring(2,3));
    setText("letter4" , userGuess.substring(3,4));
    setText("letter5" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter1","background-color","green");
  } if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter2","background-color","green");
  } if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter3","background-color","green");
  } if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter4","background-color","green");
  } if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter5","background-color","green");
  } if (userGuess == randomWord){
    setText("input1", "You got it!");
    setText("title3", "You got it!");
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter1","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter1","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter1","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter1","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter2","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter2","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter2","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter2","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter3","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter3","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter3","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter3","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter4","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter4","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter4","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter4","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter5","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter5","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter5","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter5","background-color","yellow");
  } 
  } else if (guessNumber == 1){
    setText("letter21" , userGuess.substring(0,1));
    setText("letter22" , userGuess.substring(1,2));
    setText("letter23" , userGuess.substring(2,3));
    setText("letter24" , userGuess.substring(3,4));
    setText("letter25" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter21","background-color","green");
  }  if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter22","background-color","green");
  }  if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter23","background-color","green");
  }  if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter24","background-color","green");
  }  if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter25","background-color","green");
    } if (userGuess == randomWord){
    setText("input1", "You got it!");
    setText("title3", "You got it!");
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter21","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter21","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter21","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter21","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter22","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter22","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter22","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter22","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter23","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter23","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter23","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter23","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter24","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter24","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter24","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter24","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter25","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter25","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter25","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter25","background-color","yellow");
  } 
  } else if (guessNumber == 2){
    setText("letter31" , userGuess.substring(0,1));
    setText("letter32" , userGuess.substring(1,2));
    setText("letter33" , userGuess.substring(2,3));
    setText("letter34" , userGuess.substring(3,4));
    setText("letter35" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter31","background-color","green");
  }  if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter32","background-color","green");
  }  if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter33","background-color","green");
  }  if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter34","background-color","green");
  }  if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter35","background-color","green");
  } if (userGuess == randomWord){
    setText("input1", "You got it!");
    setText("title3", "You got it!");
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter31","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter31","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter31","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter31","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter32","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter32","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter32","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter32","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter33","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter33","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter33","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter33","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter34","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter34","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter34","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter34","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter35","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter35","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter35","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter35","background-color","yellow");
  } 
  } else if (guessNumber == 3){
    setText("letter41" , userGuess.substring(0,1));
    setText("letter42" , userGuess.substring(1,2));
    setText("letter43" , userGuess.substring(2,3));
    setText("letter44" , userGuess.substring(3,4));
    setText("letter45" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter41","background-color","green");
  }  if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter42","background-color","green");
  }  if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter43","background-color","green");
  }  if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter44","background-color","green");
  }  if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter45","background-color","green");
  } if (userGuess == randomWord){
    setText("input1", "You got it!");
  setText("title3", "You got it!");
  
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter41","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter41","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter41","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter41","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter42","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter42","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter42","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter42","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter43","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter43","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter43","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter43","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter44","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter44","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter44","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter44","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter45","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter45","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter45","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter45","background-color","yellow");
  } 
  } else if (guessNumber == 4){
    setText("letter51" , userGuess.substring(0,1));
    setText("letter52" , userGuess.substring(1,2));
    setText("letter53" , userGuess.substring(2,3));
    setText("letter54" , userGuess.substring(3,4));
    setText("letter55" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter51","background-color","green");
  }  if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter52","background-color","green");
  }  if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter53","background-color","green");
  }  if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter54","background-color","green");
  }  if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter55","background-color","green");
  } if (userGuess == randomWord){
    setText("input1", "You got it!");
    setText("title3", "You got it!");
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter51","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter51","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter51","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter51","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter52","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter52","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter52","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter52","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter53","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter53","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter53","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter53","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter54","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter54","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter54","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter54","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter55","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter55","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter55","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter55","background-color","yellow");
  } 
  } else if (guessNumber == 5){
    setText("letter61" , userGuess.substring(0,1));
    setText("letter62" , userGuess.substring(1,2));
    setText("letter63" , userGuess.substring(2,3));
    setText("letter64" , userGuess.substring(3,4));
    setText("letter65" , userGuess.substring(4,5));
    if (userGuess.substring(0,1)== randomWord.substring(0,1)){
      setProperty("letter61","background-color","green");
  } if (userGuess.substring(1,2)== randomWord.substring(1,2)){
    setProperty("letter62","background-color","green");
  }  if (userGuess.substring(2,3)== randomWord.substring(2,3)){
    setProperty("letter63","background-color","green");
  }  if (userGuess.substring(3,4)== randomWord.substring(3,4)){
    setProperty("letter64","background-color","green");
  }  if (userGuess.substring(4,5)== randomWord.substring(4,5)){
    setProperty("letter65","background-color","green");
  } if (userGuess == randomWord){
    setText("input1", "You got it!");
  setText("title3", "You got it!");
  } else if (userGuess.substring(0,1)==randomWord.substring(1,2)){
    setProperty("letter61","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(2,3)){
    setProperty("letter61","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(3,4)){
    setProperty("letter61","background-color","yellow");
  }  if (userGuess.substring(0,1)==randomWord.substring(4,5)){
    setProperty("letter61","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(0,1)){
    setProperty("letter62","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(2,3)){
    setProperty("letter62","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(3,4)){
    setProperty("letter62","background-color","yellow");
  }  if (userGuess.substring(1,2)==randomWord.substring(4,5)){
    setProperty("letter62","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(0,1)){
    setProperty("letter63","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(1,2)){
    setProperty("letter63","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(3,4)){
    setProperty("letter63","background-color","yellow");
  }  if (userGuess.substring(2,3)==randomWord.substring(4,5)){
    setProperty("letter63","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(0,1)){
    setProperty("letter64","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(1,2)){
    setProperty("letter64","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(2,3)){
    setProperty("letter64","background-color","yellow");
  }  if (userGuess.substring(3,4)==randomWord.substring(4,5)){
    setProperty("letter64","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(0,1)){
    setProperty("letter65","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(1,2)){
    setProperty("letter65","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(2,3)){
    setProperty("letter65","background-color","yellow");
  }  if (userGuess.substring(4,5)==randomWord.substring(3,4)){
    setProperty("letter65","background-color","yellow");
  } if (userGuess != randomWord){
    setText("input1", "Sorry! The word is " + randomWord);
    setText("title3", "Sorry! The word is " + randomWord);
  }
  } 
}

